﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using ShopBridge.Controllers.api;
using ShopBridge.Dal;
using ShopBridge.Models;
using System.Web.Mvc;
using System.Web.Http.Results;

namespace ShopBridge.NUnitTests
{
    [TestFixture]
    public class ApiProductControllerTest
    {
        IProductDal _productDal;
        ProductController _controller;
        public ApiProductControllerTest()
        {
            _productDal = new MockProductDal();
            _controller= new ProductController(_productDal);
        }

        [Test]
        public void GetProducts_WhenCalled_ReturnsOkResult()
        {
            // Act
            var result = _controller.GetProducts() as OkNegotiatedContentResult<IList<Product>>;

            // Assert
            Assert.IsInstanceOf<OkNegotiatedContentResult<IList<Product>>>(result);
        }

        [Test]
        public void GetProducts_WhenCalled_ReturnsAllItems()
        {
            // Act 
            var contentResult = _controller.GetProducts() as OkNegotiatedContentResult<IList<Product>>;

            // Assert
            Assert.IsNotNull(contentResult);
            var products = contentResult.Content;
            Assert.AreEqual(4, products.Count);
        }

        [Test]
        public void ProductAdd_ValidObjectPassed_ReturnsCreatedResponse()
        {
            // Arrange             
            Product product = new Product()
            {
                Id = 5,
                Name = "Computer",
                Price = 25000,
                Description = "Personal Computer"
            };

            // Act
            var response = _controller.AddProduct(product);

            // Assert
            //Assert.Equals(1, response);
            Assert.IsInstanceOf<System.Int32>(response);
        }

        [Test]
        public void ProductAdd_ValidObjectPassed_ReturnedResponseHasCreatedItem()
        {
            // Arrange             
            Product product = new Product()
            {
                Id = 5,
                Name = "Computer",
                Price = 25000,
                Description = "Personal Computer"
            };

            // Act
            var response = _controller.AddProduct(product);

            // Assert  
            Assert.AreEqual(1, response);
        }

        [Test]
        public void GetProductById_UnknownIdPassed_ReturnsNotFoundResult()
        {
            // Act
            var notFoundResult = _controller.GetProductById(6);

            // Arrange
            Assert.IsInstanceOf<NotFoundResult>(notFoundResult);
        }

        [Test]
        public void GetProductById_ExistingIdPassed_ReturnsOkResult()
        {
            // Act
            var result = _controller.GetProductById(1) as OkNegotiatedContentResult<Product>;

            //Arrange
            Assert.IsInstanceOf<OkNegotiatedContentResult<Product>>(result);
        }

        [Test]
        public void GetProductById_ExistingIdPassed_ReturnsRightItem()
        {
            // Act
            var result = _controller.GetProductById(1) as OkNegotiatedContentResult<Product>;

            //Arrange
            Assert.IsNotNull(result);
            Assert.AreEqual(1,result.Content.Id);
        }
    }
}
