﻿using NUnit.Framework;
using ShopBridge.Controllers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ShopBridge.NUnitTests
{
    [TestFixture]
    public class ProductControllerTest
    {
        //[Test]
        public void TestIndexView()
        {
            // Arrange
            ProductController controller = new ProductController();

            // Act
            var actionResultTask = controller.Index();
            var viewResult = actionResultTask.Result as ViewResult;
            actionResultTask.Wait();

            // Assert
            Assert.That(viewResult.ViewName, Is.EqualTo("Index"));
        }

        //[Test]
        public void TestDisplayProductInformationView()
        {
            // Arrange
            ProductController controller = new ProductController();

            // Act
            ViewResult result = controller.DisplayProductInformation(1) as ViewResult;

            // Assert
            Assert.That(result.ViewName, Is.EqualTo("DisplayProductInformation"));
        }

    }
}
