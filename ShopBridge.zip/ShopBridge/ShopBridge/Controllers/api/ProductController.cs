﻿using ShopBridge.Dal;
using ShopBridge.Models;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace ShopBridge.Controllers.api
{
    public class ProductController : ApiController
    {
        private readonly IProductDal _productDal;
        public ProductController(IProductDal productDal)
        {
            //_productDal = new ProductDal();
            _productDal = productDal;
        }

        public ProductController()
        {

        }

        [HttpPost]
        public int AddProduct([FromBody]Product product)
        {
            int i = 0;
            if (ModelState.IsValid)
            {
                using (Context context = new Context())
                {
                    //ProductDal productDal = new ProductDal();
                    //i = productDal.AddProduct(product);               
                    i = _productDal.AddProduct(product);
                }
            };
            return i;
        }

        [HttpGet]
        [Route("api/Product/FetchProducts")]
        public IHttpActionResult GetProducts()
        {
            IList<Product> products ;
            using (Context context = new Context())
            {
                //ProductDal productDal = new ProductDal();
                //products = productDal.GetProducts().ToList<Product>();
                products = _productDal.GetProducts().ToList<Product>();
            }
            return Ok(products);
        }

        [HttpGet]
        [Route("api/Product/FetchProductById/{id}")]
        public IHttpActionResult GetProductById(int id)
        {
            Product product = new Product();
            using (Context context = new Context())
            {
                //ProductDal productDal = new ProductDal();
                //product = productDal.GetProductById(id);
                product = _productDal.GetProductById(id);                
            }
            if (product == null) 
            {
                return NotFound();
            }
            return Ok(product);
        }
    }
}
