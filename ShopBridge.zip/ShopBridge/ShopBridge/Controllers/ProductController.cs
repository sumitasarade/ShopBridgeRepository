﻿using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace ShopBridge.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        public ProductController()
        {

        }

        // GET: Product
        public async Task<ActionResult> Index()
        {
            IEnumerable<Product> products = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44333/api/");
                //HTTP GET
                var responseTask = await client.GetAsync("Product/FetchProducts");
                //responseTask.Wait();

                //var result = responseTask.Result;
                //if (result.IsSuccessStatusCode)
                if (responseTask.IsSuccessStatusCode)
                {
                    products = await responseTask.Content.ReadAsAsync<IList<Product>>();
                    //var readTask = result.Content.ReadAsAsync<IList<Product>>();
                    //readTask.Wait();

                    //products = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    products = Enumerable.Empty<Product>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(products);
        }

        public ActionResult DisplayProductInformation(int id)
        {
            Product product = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44333/api/");
                //HTTP GET
                var responseTask = client.GetAsync("Product/FetchProductById/" + id);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Product>();
                    readTask.Wait();

                    product = readTask.Result;
                }

            }
            return View(product);
        }
    }
}