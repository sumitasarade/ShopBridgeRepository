﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ShopBridge.Models
{
    public class Product
    {      
        public int Id { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please Enter Product Name.")]
        [DisplayName("Product Name")]
        public string Name { get; set; }

        //[Required]
        [Required(AllowEmptyStrings = false, ErrorMessage = "This field is required.")]
        public string Description { get; set; }

        //private decimal _price;

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Price Should be greater than 0.")]
        public decimal Price { get; set; }

    }
}