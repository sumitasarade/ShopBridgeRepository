﻿using System.Data.Entity;

namespace ShopBridge.Models
{
    public class Context : DbContext
    {
        public Context() : base("name=constr")
        {

        }
        public virtual DbSet<Product> Products { get; set; }
    }
}