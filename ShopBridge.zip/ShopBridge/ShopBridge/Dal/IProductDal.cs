﻿using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge.Dal
{
    public interface IProductDal
    {
        int AddProduct(Product product);

        IEnumerable<Product> GetProducts();

        Product GetProductById(int id);
    }
}
