﻿using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopBridge.Dal
{
    public class MockProductDal : IProductDal
    {
        private readonly List<Product> _products;

        public MockProductDal()
        {
            _products = new List<Product>()
            {
                new Product()
                {
                    Id=1,
                    Name="Pen",
                    Price=20,
                    Description="Parker Pen"
                },
                new Product()
                {
                    Id=2,
                    Name="Pencil",
                    Price=10,
                    Description="Apsara Pen"
                },
                new Product()
                {
                    Id=3,
                    Name="Laptop",
                    Price=40000,
                    Description="Dell Laptop"
                },
                new Product()
                {
                    Id=4,
                    Name="Mouse",
                    Price=1000,
                    Description="iBall"
                },

            };
        }
        public int AddProduct(Product product)
        {
            _products.Add(product);
            return 1;
        }

        public Product GetProductById(int id)
        {
            return _products.FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Product> GetProducts()
        {
            return _products;
        }
    }
}