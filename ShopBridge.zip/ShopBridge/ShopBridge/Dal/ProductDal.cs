﻿using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ShopBridge.Dal
{
    public class ProductDal:IProductDal
    {
        protected readonly Context context = new Context();

        public int AddProduct(Product product)
        {
            context.Products.Add(product);
            return context.SaveChanges();
        }
        public IEnumerable<Product> GetProducts()
        {
            return context.Products;
        }
        public Product GetProductById(int id)
        {
            return context.Products.Find(id);
        }
    }
}